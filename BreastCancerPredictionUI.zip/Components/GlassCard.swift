import SwiftUI

struct GlassCard<Content: View>: View {
    let content: () -> Content

    var body: some View {
        content()
            .padding()
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 25, style: .continuous))
            .shadow(radius: 10)
    }
}