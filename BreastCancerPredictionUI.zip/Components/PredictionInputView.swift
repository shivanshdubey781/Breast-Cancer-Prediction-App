import SwiftUI

struct PredictionInputView: View {
    @StateObject private var viewModel = PredictionViewModel()

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    GlassCard {
                        VStack {
                            Text("Personal Information").font(.title2)
                            SliderInputField(title: "Age", range: 0...100, value: $viewModel.age)
                        }
                    }

                    GlassCard {
                        VStack {
                            Text("Medical History").font(.title2)
                            SliderInputField(title: "Glucose", range: 0...200, value: $viewModel.glucose)
                            SliderInputField(title: "Insulin", range: 0...300, value: $viewModel.insulin)
                        }
                    }

                    Button(action: viewModel.predict) {
                        Text("Predict")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }

                    if !viewModel.predictionResult.isEmpty {
                        Text("Result: \(viewModel.predictionResult)")
                            .font(.title2)
                            .padding()
                    }
                }
                .padding()
            }
            .navigationTitle("Breast Cancer AI")
        }
    }
}