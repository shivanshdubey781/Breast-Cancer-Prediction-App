import SwiftUI

struct SliderInputField: View {
    let title: String
    let range: ClosedRange<Double>
    @Binding var value: Double

    var body: some View {
        VStack(alignment: .leading) {
            Text("\(title): \(Int(value))")
                .font(.headline)
            Slider(value: $value, in: range, step: 1)
        }
        .padding()
    }
}