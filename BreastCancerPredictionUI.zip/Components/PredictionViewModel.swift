import Foundation
import Combine

class PredictionViewModel: ObservableObject {
    @Published var age: Double = 50
    @Published var glucose: Double = 100
    @Published var insulin: Double = 15
    @Published var predictionResult: String = ""
    private var cancellables = Set<AnyCancellable>()

    func predict() {
        guard let url = URL(string: "https://your-api-url.onrender.com/predict") else { return }

        let parameters: [String: Any] = [
            "age": age,
            "glucose": glucose,
            "insulin": insulin
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: parameters)

        URLSession.shared.dataTaskPublisher(for: request)
            .map { $0.data }
            .decode(type: PredictionResponse.self, decoder: JSONDecoder())
            .replaceError(with: PredictionResponse(prediction: "Error"))
            .receive(on: DispatchQueue.main)
            .sink { [weak self] response in
                self?.predictionResult = response.prediction
            }
            .store(in: &cancellables)
    }
}

struct PredictionResponse: Decodable {
    let prediction: String
}